<?php
class HomeController {
    public function index() {
        require_once 'views/home.php';
    }
}
?>