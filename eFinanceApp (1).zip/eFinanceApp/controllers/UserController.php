<?php
class UserController {

    
    // protected $conn;

    // // Constructor to initialize the database connection
    // public function __construct($conn)
    // {
    //     $this->conn = $conn;
    // }

    // Function to handle profile image upload
    private function uploadProfileImage($file)
    {
        $targetDir = "uploads/pro_pic/";
        $targetFile = $targetDir . basename($file["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $uploadOk = 1;

        // Check if image file is a valid image
        if (isset($file)) {
            $check = getimagesize($file["tmp_name"]);
            if ($check === false) {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }

        // Check file size (limit to 2MB)
        if ($file["size"] > 2000000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if everything is OK
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
            return null;
        } else {
            if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                return basename($file["name"]);
            } else {
                echo "Sorry, there was an error uploading your file.";
                return null;
            }
        }
    }

    public function updateProfile($data, $file)
    {
        // Get user data from the form submission
        $name = $data['name'] ?? '';
        $username = $data['username'] ?? '';
        $mobile_no = $data['mobile_no'] ?? '';
        $address = $data['address'] ?? '';
        $gender = $data['gender'] ?? '';
        $dob = $data['dob'] ?? '';

        // Get the current profile image from the session
        $currentProfileImg = $_SESSION['profile_img'] ?? '';

        // Check if a new profile image is uploaded
        if (isset($file['profile_img']) && $file['profile_img']['error'] == 0) {
            $profileImg = $this->uploadProfileImage($file['profile_img']);
            if ($profileImg) {
                // If a new image is uploaded, update the profile image in the session
                $_SESSION['profile_img'] = $profileImg;
            } else {
                // If image upload fails, return an error response
                return json_encode(['status' => 'error', 'message' => 'Error uploading profile image.']);
            }
        } else {
            // If no new image is uploaded, keep the existing one
            $profileImg = $currentProfileImg;
        }

        // Update the user's information in the database
        $sql = "UPDATE users SET name = ?, username = ?, mobile_no = ?, address = ?, gender = ?, dob = ?, profile_img = ? WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssssi", $name, $username, $mobile_no, $address, $gender, $dob, $profileImg, $_SESSION['id']);

        if ($stmt->execute()) {
            // Update session data after successful update
            $_SESSION['name'] = $name;
            $_SESSION['username'] = $username;
            $_SESSION['mobile_no'] = $mobile_no;
            $_SESSION['address'] = $address;
            $_SESSION['gender'] = $gender;
            $_SESSION['dob'] = $dob;

            return json_encode(['status' => 'success', 'message' => 'Profile updated successfully.']);
        } else {
            return json_encode(['status' => 'error', 'message' => 'Error updating profile. Please try again.']);
        }
    }

    function check_duplicate()
    {
        if($_POST["table"] == "users")
        {
            if($_POST["column_name"] == "username")
            {
                
            }
        }
    }



    public function index() {
        require_once 'views/home.php';
    }

    public function login_page()
    {
        require_once "views/login.php";
    }

   
    public function profile()
    {
        session_start();


        // Check if the user is logged in
        if (!isset($_SESSION['id'])) {
            header("Location: login.php");
            exit();
        }

        require_once 'views/profile.php';
    }

    public function signup_page()
    {
        require_once "views/login.php";
    }
}

?>