<?php
require_once __DIR__ . '/../config/config.php';


class UserModel {
    public function validateUser($username, $password)
    {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
        $stmt->execute([$username, $password]); // Pass both username and password
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) 
        {
            session_start();

            foreach ($user as $key => $value) {
                $_SESSION[$key] = $value;
            }

            return true;
        }

        return false; // Invalid credentials if no user is found

    }
}

?>