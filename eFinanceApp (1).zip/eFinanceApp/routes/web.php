<?php
require_once 'controllers/HomeController.php';
require_once 'controllers/UserController.php';


$HomeController = new HomeController();
$UserController = new UserController();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if ($uri === '/eFinanceApp/') {
    $HomeController->index();
} 

else if ($uri === '/eFinanceApp/login.php') {
    $HomeController->login_page();
} 
else if ($uri === '/eFinanceApp/processLogin.php') {
    $HomeController->login_check();
} 
else if ($uri === '/eFinanceApp/dashboard.php') {
    $HomeController->dashboard();
} 
else if ($uri === '/eFinanceApp/profile.php') {
    $UserController->profile();
} 
else if ($uri === '/eFinanceApp/update_profile.php') {
    $UserController->updateProfile();
} 
else if ($uri === '/eFinanceApp/check_duplicate.php') {
    $UserController->check_duplicate();
} 

elseif ($uri === '/eFinanceApp/signup' || $uri === '/eFinanceApp/signup.php') {
    $HomeController->signup_page();
} else {
    echo "404 Not Found";
}
?>
