<?php
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | eFinanceApp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .profile-img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
        }
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        .profile-header {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
        }
        .card {
            border-radius: 15px;
        }
        .card-body {
            padding: 2rem;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 50px;
            padding: 10px 20px;
            transition: all 0.3s ease;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<script src="public/jquery/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>

<script>
    $(document).ready(function() {
        // Initialize form validation
        $("form").validate({
            rules: {
                name: {
                    required: true
                },
                username: {
                    required: true,
                    minlength: 3,
                    maxlength: 20,
                    remote: {
                        url: "check_duplicate.php",
                        type: "POST",
                        data: {
                            column_name: "username"
                            table: "users"
                        },
                        dataFilter: function(response) {
                            var result = JSON.parse(response);
                            if(result.status === 'error') {
                                return false;
                            } else {
                                return true;
                            }
                        }
                    }
                },
                mobile_no: {
                    required: true,
                    minlength: 10,
                    maxlength: 15,
                    digits: true,
                    remote: {
                        url: "check_duplicate.php",
                        type: "POST",
                        data: {
                            mobile_no: function() {
                                return $("#mobile_no").val(); 
                            },
                            action: "check_mobile_no"
                        }
                    }
                },
                address: {
                    required: true
                },
                gender: {
                    required: true
                },
                dob: {
                    required: true
                }
            },
            messages: {
                username: {
                    required: "Please enter your username",
                    remote: "Username is already taken"
                },
                mobile_no: {
                    required: "Please enter your mobile number",
                    remote: "Mobile number is already in use"
                }
            },
            submitHandler: function(form) {
                event.preventDefault();

                var formData = new FormData(form);
                
                var fileInput = $("input[name='profile_img']")[0];
                if (fileInput.files.length > 0) {
                    formData.append("profile_img", fileInput.files[0]);
                }

                $.ajax({
                    url: 'update_profile.php', // Make sure this URL corresponds to the correct route in your controller
                    type: 'POST',
                    data: formData,
                    dataType: 'json', 
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.status === 'success') {
                            alert(response.message);
                            location.reload(); // This will reload the page to reflect the updated profile
                        } else {
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                    }
                });
            }
        });
    });

</script>


    <!-- Sidebar -->
    <?php include __DIR__ . '/includes/menu.php'; ?>

    <!-- Main Content -->
    <div class="content">
        <div class="container">
            <h1 class="profile-header">Profile Information</h1>

            <!-- User Info -->
            <div class="row mt-4">
                <div class="col-md-4 text-center">
                    <img src="uploads/pro_pic/<?php echo htmlspecialchars($_SESSION['profile_img']); ?>" alt="Profile Image" class="profile-img mb-4">
                    
                        <input type="file" name="profile_img" accept="image/*" class="form-control mb-3">
                        <button type="submit" class="btn-custom">Upload New Image</button>
                </div>

                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Update Your Information</h5>

                            <form id="form"  method="POST">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($_SESSION['name']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($_SESSION['username']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="mobile_no" class="form-label">Mobile No</label>
                                    <input type="text" name="mobile_no" id="mobile_no" class="form-control" value="<?php echo htmlspecialchars($_SESSION['mobile_no']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <input type="text" name="address" id="address" class="form-control" value="<?php echo htmlspecialchars($_SESSION['address']); ?>" required>
                                </div>

                                <!-- Gender Field -->
                                <div class="mb-3">
                                    <label for="gender" class="form-label">Gender</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="Male" <?php echo ($_SESSION['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?php echo ($_SESSION['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                                    </select>
                                </div>

                                <!-- Date of Birth Field -->
                                <div class="mb-3">
                                    <label for="dob" class="form-label">Date of Birth</label>
                                    <input type="date" name="dob" id="dob" class="form-control" value="<?php echo htmlspecialchars(substr($_SESSION['dob'], 0, 10)); ?>" required>
                                </div>


                                <button type="submit" class="btn-custom">Update Information</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
