<?php
// Example route
require_once 'controllers/HomeController.php';

if ($_SERVER['REQUEST_URI'] === '/eFinanceApp/' || $_SERVER['REQUEST_URI'] === '/eFinanceApp/index.php') {
    $controller = new HomeController();
    $controller->index();
} else {
    echo "404 Not Found";
}
?>