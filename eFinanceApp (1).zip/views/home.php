<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eFinanceApp</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <h1>Welcome to eFinanceApp</h1>
    <p>Your one-stop solution for managing finances.</p>
</body>
</html>